import requests
import json

facility_id_list = ['231870']
for fac_id in facility_id_list:
    url = f'https://ridb.recreation.gov/api/v1/facilities/{fac_id}/campsites?limit=50&offset=0'
    api_key = '86316c50-27cb-4c0a-a0b0-0f39c3893565'
    headers = {
        'apiKey': api_key,
        'Content-Type': 'application/json'
    }

    response = requests.get(url, headers=headers)
    json_object = json.loads(response.text)
    for data in json_object['RECDATA']:
        campsite_name = data['CampsiteName']
        campsite_type = data['CampsiteType']
        campsite_id = data['CampsiteID']
        # print(f'{campsite_name} {campsite_type} {campsite_id}')
    # json_formatted_str = json.dumps(json_object, indent=4)
    # print(json_formatted_str)
    # print(json_formatted_str)
        if campsite_name == '012':
            entity_id = data['CampsiteID']
            print(campsite_id)
            
 
    
            url = f'https://ridb.recreation.gov/api/v1/campsites/{entity_id}?limit=50&offset=0'
            api_key = '86316c50-27cb-4c0a-a0b0-0f39c3893565'
            headers = {
                'apiKey': api_key,
                'Content-Type': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            json_object = json.loads(response.text)
            json_formatted_str = json.dumps(json_object, indent=4)
            print(json_formatted_str)
    